$(document).ready(function () {

    $("#mobile-menu").mobileMenu({
        MenuWidth: 250,
        SlideSpeed : 300,
        WindowsMaxWidth : 767,
        PagePush : true,
        FromLeft : true,
        Overlay : true,
        CollapseMenu : true,
        ClassName : "mobile-menu"
    });

    $('#btnSignUp').click(function () {
        console.log("Navigating to #userSignUp"); // Debug log

        // Navigate to internal page
        $.mobile.changePage('#userSignUp', {
            transition: 'slide', // Add slide transition
        });
    });

    // Handle Sign-Up Form Submission
    $(document).on('submit', '#frmUserSignUp', function (e) {
        e.preventDefault(); // Prevent form submission

        // Serialize form data
        var values = $(this).serialize();
        console.log("Sign-Up Form Data:", values); // Debug log

        // Perform AJAX request
        $.ajax({
            url: 'save-signup.php',
            type: 'POST',
            data: values,
            success: function (response) {
                console.log("Sign-Up Success:", response); // Debug log
                alert('User registered successfully!');
                $('#frmUserSignUp')[0].reset(); // Reset form
                $.mobile.changePage('#startPage', {
                    transition: 'slide', 
                    reloadPage: true 
                });
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.error('Sign-Up Error:', textStatus, errorThrown); // Debug log
            }
        });
    });
});

$(document).on('submit', '#frmAdminLogIn', function(){     
    //GET USER INPUTS FROM HTML FORMS
    aduname =  document.getElementById("Admin_Username_Log").value;
    adpass =  document.getElementById("Admin_Pass_Log").value;
    
    //CREATE AJAX TO CALL UPDATE-USER PHP SCRIPT
    $.ajax({
        url: "loginad.php?uname=" + aduname + "&pass=" + adpass,
        type : "POST",
        dataType : 'json',
        success : function(result) {
           intCount = result.totCount; 
           if(intCount==1){
                $.mobile.changePage("admin-home.php", { transition: "slide", reloadPage:true })   
           }                
        },
        error: function(xhr, resp, text) {
        console.log(xhr, resp, text);
        }
       });
   });