$('#viewapp').bind('pageshow', onReadOne);
    function onReadOne(e,data)
   {
       adminid = getUrlVars()["id"];
       $.ajax({
       url: "read-one-app.php?id=" + adminid,
       type : "POST",
       dataType : 'json',
       success : function(result) {   
           document.getElementById("uid").innerHTML = result.Applicant_ID; 
           document.getElementById("uname").innerHTML = result.Applicant_username; 
           document.getElementById("pass").innerHTML = result.Applicant_password; 
           document.getElementById("email").innerHTML = result.Applicant_email; 
           document.getElementById("fname").innerHTML = result.Applicant_FName;
           document.getElementById("mname").innerHTML = result.Applicant_MName;
           document.getElementById("lname").innerHTML = result.Applicant_LName;  
           document.getElementById("imgUser").src = "../assets/images/profPhoto.jpg";           
       },
       error: function(xhr, resp, text) {
       console.log(xhr, resp, text);
       }
   }); 
   }
   
   function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        vars[key] = value;
    });
    return vars;
    }