$('#createBatchForm').bind('pageshow', onEditForm);
   function onEditForm(e,data)
   {
      adminid = document.getElementById("sid").innerHTML;
        $.ajax({
        url: "read-comp-ad.php?id=" + adminid,
        type : "POST",
        dataType : 'json',
        success : function(result) {
            document.getElementById("Stud_ID_Edit").value = result.Stud_ID;
            document.getElementById("Batch_Create").value = result.Batch; 
            document.getElementById("Payout_Create").value = result.Payout;          
   },
   error: function(xhr, resp, text) {
   console.log(xhr, resp, text);
   }
}); 
}
     
   //WHEN EDIT BUTTON WAS CLICKED
   $(document).on('submit', '#frmCreateBatch', function(){  
       //GET USER INPUTS FROM HTML FORMS
       var values = $(this).serialize();
     
       //CREATE AJAX TO CALL UPDATE-USER PHP SCRIPT
       $.ajax({
              url: "save-batch.php",
              type: "POST",
              data: values ,
              success: function (response) {
                 $('#frmCreateBatch')[0].reset();
                 $.mobile.changePage('admin-home.php', {
                    transition: 'slide', 
                    reloadPage: true 
                }); 
              },
              error: function(jqXHR, textStatus, errorThrown) {
                 console.log(textStatus, errorThrown);
              }
          });
        
      });


$('#viewapplad').bind('pageshow', onReadOne);
    function onReadOne(e,data)
   {
       adminid = getUrlVars()["id"];
       $.ajax({
       url: "read-comp-ad.php?id=" + adminid,
       type : "POST",
       dataType : 'json',
       success : function(result) {   
           document.getElementById("sid").innerHTML = result.Stud_ID; 
           document.getElementById("appname").innerHTML = result.Applicant_Name; 
           document.getElementById("dob").innerHTML = result.Date_of_Birth; 
           document.getElementById("educlevel").innerHTML = result.Educ_level; 
           document.getElementById("yrlevel").innerHTML = result.Year_level;
           document.getElementById("school").innerHTML = result.School;
           document.getElementById("schooladd").innerHTML = result.School_address;
           document.getElementById("cors").innerHTML = result.Course_or_Strand;
           document.getElementById("batch").innerHTML = result.Batch;
           document.getElementById("payout").innerHTML = result.Payout;  
           document.getElementById("imgUser").src = "../assets/images/profPhoto.jpg";           
       },
       error: function(xhr, resp, text) {
       console.log(xhr, resp, text);
       }
   }); 
   }
   
   function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        vars[key] = value;
    });
    return vars;
    }