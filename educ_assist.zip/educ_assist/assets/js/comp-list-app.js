$('#viewappl').bind('pageshow', onReadOne);
    function onReadOne(e,data)
   {
       adminid = getUrlVars()["id"];
       $.ajax({
       url: "read-comp-app.php?id=" + adminid,
       type : "POST",
       dataType : 'json',
       success : function(result) {   
           document.getElementById("sid").innerHTML = result.Stud_ID; 
           document.getElementById("appname").innerHTML = result.Applicant_Name; 
           document.getElementById("dob").innerHTML = result.Date_of_Birth; 
           document.getElementById("educlevel").innerHTML = result.Educ_level; 
           document.getElementById("yrlevel").innerHTML = result.Year_level;
           document.getElementById("school").innerHTML = result.School;
           document.getElementById("schooladd").innerHTML = result.School_address;
           document.getElementById("cors").innerHTML = result.Course_or_Strand;
           document.getElementById("batch").innerHTML = result.Batch;
           document.getElementById("payout").innerHTML = result.Payout;  
           document.getElementById("imgUser").src = "../assets/images/profPhoto.jpg";           
       },
       error: function(xhr, resp, text) {
       console.log(xhr, resp, text);
       }
   }); 
   }
   
   function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        vars[key] = value;
    });
    return vars;
    }