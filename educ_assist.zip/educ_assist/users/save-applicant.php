<?php
// CALL DATABASE CONNECTION SCRIPT
include("../config/database.php");

session_start();

// Ensure session variable is set
if (!isset($_SESSION['applicant_id'])) {
    echo "Applicant ID is missing.";
    exit();
}

// GET DATA FROM POST REQUEST
$strStudID = $_POST['Stud_ID_Create']; 
$strApplicantName = $_POST['Applicant_Name_Create']; 
$dateDOB = $_POST['Date_of_Birth_Create']; 
$strEducLevel = $_POST['Educ_level_Create']; 
$strYearLevel = $_POST['Year_level_Create']; 
$strSchool = $_POST['School_Create']; 
$strSchoolAddress = $_POST['School_Address_Create']; 
$strCourseOrStrand = $_POST['Course_or_Strand_Create']; 
$intBatchID = $_POST['Batch_ID_Create']; 

$applicantId = $_SESSION['applicant_id']; 

// CREATE QUERY TO INSERT RECORDS INTO tbl_applicant_info
$query = "INSERT INTO tbl_applicant_info (
    Applicant_ID, 
    Stud_ID, 
    Applicant_Name, 
    Date_of_Birth, 
    Educ_level, 
    Year_level, 
    School, 
    School_address, 
    Course_or_Strand, 
    Batch_ID
) VALUES (
    :applicantId, 
    :studID, 
    :applicantName, 
    :dob, 
    :educLevel, 
    :yearLevel, 
    :school, 
    :schoolAddress, 
    :courseOrStrand, 
    :batchID
)";

// PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
$stmt = $pdo->prepare($query);

// BIND PARAMETER VALUES
$stmt->bindParam(":applicantId", $applicantId); 
$stmt->bindParam(":studID", $strStudID);
$stmt->bindParam(":applicantName", $strApplicantName);
$stmt->bindParam(":dob", $dateDOB);
$stmt->bindParam(":educLevel", $strEducLevel);
$stmt->bindParam(":yearLevel", $strYearLevel);
$stmt->bindParam(":school", $strSchool);
$stmt->bindParam(":schoolAddress", $strSchoolAddress);
$stmt->bindParam(":courseOrStrand", $strCourseOrStrand);
$stmt->bindParam(":batchID", $intBatchID);

// EXECUTE STATEMENT
if ($stmt->execute()) {
    echo "Application submitted successfully.";
} else {
    echo "Error submitting application.";
}
?>
