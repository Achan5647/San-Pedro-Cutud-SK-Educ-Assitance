<?php
    //CALL DATABASE CONNECTION SCRIPT
    include("../config/database.php");
  
    //GET USER INPUT FROM WEB FORM
    $strUname = $_POST['Admin_Username_Create'];
    $strPass = $_POST['Admin_Password_Create'];
    $strEmail = $_POST['Admin_Email_Create'];
    $strPos = $_POST['Admin_Position_Create'];
    $strPicPath = "profPhoto.jpg";
    
    //CREATE QUERY TO INSERT RECORDS
    $query = "INSERT INTO tbl_admin SET
    Admin_username=:uname, 
    Admin_password=:pass, 
    Admin_email=:email, 
    Admin_Position=:pos,
    PicPath=:path";

    //PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
    $stmt = $pdo->prepare($query);

    //BIND PARAMETER VALUES
    $stmt->bindParam(":uname", $strUname);
    $stmt->bindParam(":pass", $strPass);
    $stmt->bindParam(":email", $strEmail);
    $stmt->bindParam(":pos", $strPos);
    $stmt->bindParam(":path", $strPicPath);

    //EXECUTE STATEMENT
    $stmt->execute();  
?>