<?php
    //CALL DATABASE CONNECTION SCRIPT
    include("../config/database.php");
  
    //GET USER INPUT FROM WEB FORM
    $strBatch = $_POST['Batch_Create'];
    $strPayout = $_POST['Payout_Create'];
    $strStudID = $_POST['Stud_ID_Edit'];
  

    //CREATE QUERY TO INSERT RECORDS
    $query = "UPDATE tbl_applicant_info SET 
    Batch=:batch, 
    Payout=:payout
    WHERE Stud_ID=:sid";

    //PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
    $stmt = $pdo->prepare($query);

    //BIND PARAMETER VALUES

    $stmt->bindParam(":batch", $strBatch);
    $stmt->bindParam(":payout", $strPayout);
    $stmt->bindParam(":sid", $strStudID);

    //EXECUTE STATEMENT
    $stmt->execute();  
?>