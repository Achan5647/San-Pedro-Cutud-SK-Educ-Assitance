<?php
    //CALL DATABASE CONNECTION SCRIPT
    include("../config/database.php");
  
    //GET USER INPUT FROM WEB FORM
    $strStudID = $_POST['Stud_ID_Create'];
    $strAppname = $_POST['Applicant_Name_Create'];
    $strDOB = $_POST['Date_of_Birth_Create'];
    $strEduclevel = $_POST['Educ_level_Create'];
    $strYearlevel = $_POST['Year_level_Create'];
    $strSchool = $_POST['School_Create'];
    $strSchoolAdd = $_POST['School_Address_Create'];
    $strCourse = $_POST['Course_or_Strand_Create'];
    $strPicPath = "profPhoto.jpg";
    
    //CREATE QUERY TO INSERT RECORDS
    $query = "INSERT INTO tbl_applicant_info SET
    Stud_ID=:sid, 
    Applicant_Name=:appname, 
    Date_of_Birth=:dob, 
    Educ_level=:educlevel,
    Year_level=:yrlevel,
    School=:school,
    School_address=:schooladd,
    Course_or_Strand=:cors,
    PicPath=:path";

    //PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
    $stmt = $pdo->prepare($query);

    //BIND PARAMETER VALUES
    $stmt->bindParam(":sid", $strStudID);
    $stmt->bindParam(":appname", $strAppname);
    $stmt->bindParam(":dob", $strDOB);
    $stmt->bindParam(":educlevel", $strEduclevel);
    $stmt->bindParam(":yrlevel", $strYearlevel);
    $stmt->bindParam(":school", $strSchool);
    $stmt->bindParam(":schooladd", $strSchoolAdd);
    $stmt->bindParam(":cors", $strCourse);
    $stmt->bindParam(":path", $strPicPath);

    //EXECUTE STATEMENT
    $stmt->execute();  
?>