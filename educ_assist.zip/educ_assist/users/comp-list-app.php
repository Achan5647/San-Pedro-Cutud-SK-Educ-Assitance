<!DOCTYPE html>
<html>
    <head>
        <title>APPLICANT HOMEPAGE</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Include jQuery Mobile stylesheets -->
        <link rel="stylesheet" href="../../jquery/jquery.mobile-1.4.5.min.css">

        <!-- Include the jQuery library -->
        <script src="../../jquery/jquery-1.11.3.js"></script>

        <!-- Include the jQuery Mobile library -->
        <script src="../../jquery/jquery.mobile-1.4.5.min.js"></script>

        <link rel="stylesheet" href="../assets/css/custom.css">
        
        <div id="AdminList" data-role="page">
            <div data-role="header" data-position="fixed">
                <center><h4>APPLICATION LIST</h4></center>
                <div class="mm-toggle-wrap">
                    <div class="mm-toggle">
                        <i class="icon-menu"></i><span class="mm-label">APPLICATION LIST</span>
                    </div>            
                </div>
            </div>
            
            <div data-role="content">          
                <ul data-role="listview" style="white-space:normal">  
                    <?php
                        error_reporting(0);
                        //CALL DATABASE CONNECTION SCRIPT
                        include("../config/database.php");

                        //CREATE THE QUERY TO SELECT ALL RECORDS FROM THE TABLE
                        $query="SELECT * FROM tbl_applicant_info";
                    
                        //PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
                        $stmt = $pdo->prepare($query);
                        
                        //EXECUTE STATEMENT
                        $stmt->execute();

                        //GET RECORDS PER ROW
                        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        //LOOP AND STORE DATA RECORDS TO VARIABLES
                        foreach($rows as $row){      
                                $sid = $row["Stud_ID"];
                                $appname = $row["Applicant_Name"];
                                $dob = $row["Date_of_Birth"];
                                $educlevel = $row["Educ_level"];
                                $yrlevel = $row["Year_level"];
                                $school = $row["School"];
                                $schooladd = $row["School_address"];
                                $cors = $row["Course_or_Strand"];
                                $batch = $row["Batch"];
                                $payout = $row["Payout"];
                                $picpath = $row["PicPath"];

                            //DISPLAY RECORDS AS LIST
                            echo'    
                            <li>
                                <a href="#viewappl?id='.$sid.'" rel="external" data-transition="slide" id="userLink">
                                <img class="imgUserIcon" alt="sample" src="../assets/images/'.$picpath.'" align="left"/>
                                '.$sid.'

                                <br>
                                <font style="font-size: small">
                                '.$appname.', '.$dob.'

                                <br>
                                '.$school.', '.$yrlevel.' '.$cors.'
                                </font>
                                </a>
                            </li>
                            ';              
                            }
                        ?>
                    </ul>
                </div>
            </div>

            <!-- PAGE FOR VIEW RECORD -->
            <div id="viewappl" data-role="page">
                <div data-role="header" data-position="fixed">
                <center><h4>VIEW APPLICATION INFO</h4></center>
                </div>
                    <div data-role="content">              
                        <img class="imgUser" id="imgUser">
                        <table data-role="table" id="movie-table" data-mode="reflow" class="ui-responsive">
                        <thead>
                            <th data-priority="1">Student ID</th>
                            <th data-priority="2">Applicant Name</th>
                            <th data-priority="3">Date of Birth</th>
                            <th data-priority="4">Educational Level</th>
                            <th data-priority="5">Year Level</th>
                            <th data-priority="6">School</th>
                            <th data-priority="7">School Address</th>
                            <th data-priority="8">Course or Strand</th>
                            <th data-priority="9">Batch</th>
                            <th data-priority="10">Payout</th>
                            </tr>
                        </thead>
                        <tbody>                 
                            <tr>
                            <td><em id="sid"></td>
                            <td><em id="appname"></td>
                            <td><em id="dob"></td>
                            <td><em id="educlevel"></td>
                            <td><em id="yrlevel"></td>
                            <td><em id="school"></td>
                            <td><em id="schooladd"></td>
                            <td><em id="cors"></td>
                            <td><em id="batch"></td>
                            <td><em id="payout"></td>                
                            </tr>                 
                        </tbody>
                        </table>              
                    </div>
                    <footer id="Ftr" data-role="footer" data-position="fixed">
                    <div data-role="navbar">                 
                        <ul>                   
                            <li><a type="button" onclick="window.location.href='applicant-home.php'" id="btnList" data-icon="arrow-l" reloadPage="true" data-transition="slide">Back</a></li>
                        </ul>
                    </div>
            </div>
    </head>

    <body>
        <!-- JavaScript -->
        <script src="../assets/js/user.js"></script>
        <!-- JavaScript -->
        <script src="../assets/js/comp-list-app.js"></script>
    </body>
</html>
