<!DOCTYPE html>
<html>
    <head>
        <title>ADMIN HOMEPAGE</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Include jQuery Mobile stylesheets -->
        <link rel="stylesheet" href="../../jquery/jquery.mobile-1.4.5.min.css">

        <!-- Include the jQuery library -->
        <script src="../../jquery/jquery-1.11.3.js"></script>

        <!-- Include the jQuery Mobile library -->
        <script src="../../jquery/jquery.mobile-1.4.5.min.js"></script>

        <link rel="stylesheet" href="../assets/css/custom.css">
        
        <div id="AdminList" data-role="page">
            <div data-role="header" data-position="fixed">
                <center><h4>APPLICANT LIST</h4></center>
                <div class="mm-toggle-wrap">
                    <div class="mm-toggle">
                        <i class="icon-menu"></i><span class="mm-label">ADMIN LIST</span>
                    </div>            
                </div>
            </div>
            
            <div data-role="content">          
                <ul data-role="listview" style="white-space:normal">  
                    <?php
                        error_reporting(0);
                        //CALL DATABASE CONNECTION SCRIPT
                        include("../config/database.php");

                        //CREATE THE QUERY TO SELECT ALL RECORDS FROM THE TABLE
                        $query="SELECT * FROM tbl_applicant";
                    
                        //PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
                        $stmt = $pdo->prepare($query);
                        
                        //EXECUTE STATEMENT
                        $stmt->execute();

                        //GET RECORDS PER ROW
                        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        //LOOP AND STORE DATA RECORDS TO VARIABLES
                        foreach($rows as $row){      
                                $uid = $row["Applicant_ID"];
                                $uname = $row["Applicant_username"];
                                $pass = $row["Applicant_password"];
                                $email = $row["Applicant_email"];
                                $fname = $row["Applicant_FName"];
                                $mname = $row["Applicant_MName"];
                                $lname = $row["Applicant_LName"];
                                $picpath = $row["PicPath"];

                            //DISPLAY RECORDS AS LIST
                            echo'    
                            <li>
                                <a href="#viewapp?id='.$uid.'" rel="external" data-transition="slide" id="userLink">
                                <img class="imgUserIcon" alt="sample" src="../assets/images/'.$picpath.'" align="left"/>
                                '.$uid.'

                                <br>
                                <font style="font-size: small">
                                '.$uname.', '.$email.'

                                <br>
                                '.$lname.', '.$fname.' '.$mname.'
                                </font>
                                </a>
                            </li>
                            ';              
                            }
                        ?>
                    </ul>
                </div>
            </div>
            <!-- PAGE FOR VIEW RECORD -->
            <div id="viewapp" data-role="page">
                <div data-role="header" data-position="fixed">
                <center><h4>VIEW ADMIN INFO</h4></center>
                </div>
                    <div data-role="content">              
                        <img class="imgUser" id="imgUser">
                        <table data-role="table" id="movie-table" data-mode="reflow" class="ui-responsive">
                        <thead>
                            <th data-priority="1">Applicant ID</th>
                            <th data-priority="2">Applicant username</th>
                            <th data-priority="3">Applicant password</th>
                            <th data-priority="4">Applicant Email</th>
                            <th data-priority="5">Applicant First Name</th>
                            <th data-priority="6">Applicant Middle Name</th>
                            <th data-priority="7">Applicant Last Name</th>
                            </tr>
                        </thead>
                        <tbody>                 
                            <tr>
                            <td><em id="uid"></td>
                            <td><em id="uname"></td>
                            <td><em id="pass"></td>
                            <td><em id="email"></td>
                            <td><em id="fname"></td>
                            <td><em id="mname"></td>
                            <td><em id="lname"></td>                
                            </tr>                 
                        </tbody>
                        </table>              
                    </div>
                    <footer id="Ftr" data-role="footer" data-position="fixed">
                    <div data-role="navbar">                 
                        <ul>                   
                            <li><a type="button" onclick="window.location.href='admin-home.php'" id="btnList" data-icon="arrow-l" reloadPage="true" data-transition="slide">Back</a></li>
                            <li><a type="button" href="#editAdminForm" id="btnEdit" data-icon="edit" reloadPage="true" data-transition="slide">Edit Record</a></li>
                            <li><a type="button" href="#" id="btnDelete" data-icon="delete">Delete Record</a></li>
                        </ul>
                    </div>
            </div>
    </head>

    <body>
        <!-- JavaScript -->
        <script src="../assets/js/user.js"></script>
        <!-- JavaScript -->
        <script src="../assets/js/app-list.js"></script>
    </body>
</html>
