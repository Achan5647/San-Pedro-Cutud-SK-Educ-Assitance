<!DOCTYPE html>
<html>
    <head>
        <title>USER APPLICATION</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Include jQuery Mobile stylesheets -->
        <link rel="stylesheet" href="../../jquery/jquery.mobile-1.4.5.min.css">

        <!-- Include the jQuery library -->
        <script src="../../jquery/jquery-1.11.3.js"></script>

        <!-- Include the jQuery Mobile library -->
        <script src="../../jquery/jquery.mobile-1.4.5.min.js"></script>
    </head>

    <body>
        <div id="AdminList" data-role="page">
        <div data-role="header" data-position="fixed">
            <center><h4>APPLICANT LIST</h4></center>
            <div class="mm-toggle-wrap">
                <div class="mm-toggle">
                    <i class="icon-menu"></i><span class="mm-label">APPLICANT LIST</span>
                </div>            
            </div>
        </div>
            <div data-role="content">          
            <ul data-role="listview" style="white-space:normal">  
                <?php
                    error_reporting(0);
                    //CALL DATABASE CONNECTION SCRIPT
                    include("../config/database.php");

                    //CREATE THE QUERY TO SELECT ALL RECORDS FROM THE TABLE
                    $query="SELECT * FROM tbl_applicant";
                  
                    //PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
                    $stmt = $pdo->prepare($query);
                    
                    //EXECUTE STATEMENT
                    $stmt->execute();

                    //GET RECORDS PER ROW
                    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    //LOOP AND STORE DATA RECORDS TO VARIABLES
                    foreach($rows as $row){      
                            $uid = $row["Applicant_ID"];
                            $uname = $row["Applicant_username"];
                            $pass = $row["Applicant_password"];
                            $email = $row["Applicant_email"];
                            $fname = $row["Applicant_FName"];
                            $lname = $row["Applicant_LName"];
                            $picpath = $row["PicPath"];

                        //DISPLAY RECORDS AS LIST
                        echo'    
                        <li>
                            <a href="#viewRecord?id='.$uid.'" rel="external" data-transition="slide" id="userLink">
                            <img class="imgUserIcon" alt="sample" src="../assets/images/'.$picpath.'" align="left"/>
                            '.$uid.'

                            <br>
                            <font style="font-size: small">
                            '.$lname.', '.$fname.' '.$mname.' 

                            <br>
                            '.$email.'
                            </font>
                            </a>
                        </li>
                        ';              
                        }
                    ?>
                 </ul>
            </div>
        <!-- JavaScript -->
        <script src="../assets/js/user.js"></script>
    </body>
</html>
