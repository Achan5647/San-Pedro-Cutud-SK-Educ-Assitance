<?php
error_reporting(0);
//CALL DATABASE CONNECTION SCRIPT
include("../config/database.php");

//CREATE THE QUERY TO SELECT ALL RECORDS FROM THE TABLE
$query="SELECT * FROM tbl_applicant_info WHERE Stud_ID=?";

//PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
$stmt = $pdo->prepare($query);

$id = isset($_GET['id']) ? $_GET['id'] : die();
//BIND VALUE TO DATABASE PARAMETER
$stmt->bindValue(1, $id);

//EXECUTE STATEMENT
$stmt->execute();

$user_arr=array();
$user_arr["records"]=array();

//GET RECORDS PER ROW
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    // extract row
    // this will make $row['name'] to
    // just $name only
    extract($row);

    $user_arr = array(
        "Stud_ID" =>  $Stud_ID,
        "Applicant_Name" => $Applicant_Name,
        "Date_of_Birth" => $Date_of_Birth,
        "Educ_level" => $Educ_level,
        "Year_level" => $Year_level,
        "School" => $School,
        "School_address" => $School_address,
        "Course_or_Strand" => $Course_or_Strand,
        "Batch" => $Batch,
        "Payout" => $Payout,
        "PicPath" => $PicPath   
    );
    }
    echo json_encode($user_arr);
?>
