<!DOCTYPE html>
<html>
    <head>
        <title>APPLICANT HOMEPAGE</title>
        <!-- Include meta tag to ensure proper rendering and touch zooming -->
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Include jQuery Mobile stylesheets -->
        <link rel="stylesheet" href="../../jquery/jquery.mobile-1.4.5.min.css">

        <!-- Include the jQuery library -->
        <script src="../../jquery/jquery-1.11.3.js"></script>

        <!-- Include the jQuery Mobile library -->
        <script src="../../jquery/jquery.mobile-1.4.5.min.js"></script>     

        <!-- Include the Custom CSS -->
        <link rel="stylesheet" href="../assets/css/custom.css">

        <!-- Include the CSS For the Sliding Menu -->
        <link href="../assets/css/normalize.css" rel="stylesheet">
        <link href="../assets/css/site-icons.css" rel="stylesheet">
        <link href="../assets/css/style.css" rel="stylesheet">
        <link href="../assets/css/jquery.mobile-menu.css" rel="stylesheet">

        <style>
        #Ftr #btncomplete {
            width: 300px; 
            height: 35px;
            margin: 0 auto; 
            font-size: 17px;
            background-color:rgb(231, 231, 231); 
            color: black; 
            border: none; 
            border-radius: 5px; 
            padding: 10px; 
            text-align: center; 
            display: flex; 
            align-items: center;
            justify-content: center;
        }

        #Ftr {
            background: none;
            border: none;
        }

        .picture-container {
        display: flex;
        flex-wrap: wrap; 
        justify-content: center; 
        gap: 10px; 
        }

        .picture img {
            width: 100%;
            max-width: 320px; 
            height: auto; 
            border-radius: 5px; 
        }

        @media screen and (max-width: 768px) {
            .picture-container {
                justify-content: center; 
            }

            .picture img {
                max-width: 90%; 
            }

            #Ftr #btncomplete {
                width: 90%; 
                font-size: 14px; 
            }
        }

        @media screen and (max-width: 480px) {
            .picture-container {
                flex-direction: column; 
                align-items: center; 
            }

            .picture img {
                max-width: 100%; 
            }

            #Ftr #btncomplete {
                width: 100%;
                font-size: 12px; 
            }
        }
        </style>

    </head>

    <body>
    <div id="overlay"></div>
        <!-- PAGE FOR APPLICANT LIST -->
        <div id="announcementPage" data-role="page">
            <div data-role="header" data-position="fixed">
                <center><h4>ANNOUNCEMENT</h4></center>
                <div class="mm-toggle-wrap">
                <div class="mm-toggle">
                    <i class="icon-menu"></i><span class="mm-label">ADMIN</span>
                </div>            
            </div>
            </div>

            <div data-role="content" data-position = "fixed">
            <div class="picture-container">
                <div class="picture" id="image1">
                    <img src="../assets/images/image1.jpg" alt="Image 1">
                </div>
                <div class="picture" id="image2">
                    <img src="../assets/images/image2.jpg" alt="Image 2">
                </div>
                <div class="picture" id="image3">
                    <img src="../assets/images/image3.jpg" alt="Image 3">
                </div>
                <div class="picture" id="image4">
                    <img src="../assets/images/image4.jpg" alt="Image 4">
                </div>
                <div class="picture" id="image5">
                    <img src="../assets/images/image5.jpg" alt="Image 5">
                </div>
                <div class="picture" id="image6">
                    <img src="../assets/images/image6.jpg" alt="Image 6">
                </div>
                <div class="picture" id="image7">
                    <img src="../assets/images/image7.jpg" alt="Image 7">
                </div>
                <div class="picture" id="image8">
                    <img src="../assets/images/image8.jpg" alt="Image 8">
                </div>
                <div class="picture" id="image9">
                    <img src="../assets/images/image9.jpg" alt="Image 9">
                </div>
                <div class="picture" id="image10">
                    <img src="../assets/images/image10.jpg" alt="Image 10">
                </div>
                <div class="picture" id="image11">
                    <img src="../assets/images/image11.jpg" alt="Image 11">
                </div>
                <div class="picture" id="image12">
                    <img src="../assets/images/image12.jpg" alt="Image 12">
                </div>
            </div>

            </div>

            <footer id="Ftr" data-role="footer" data-position="fixed">
                <div data-role="navbar">                 
                    <ul>                   
                        <li><a type="button" href="#completeApplicationForm" reloadPage="true" id="btncomplete" class="ui-btn ui-shadow ui-corner-all">Finish your Application</a></li>
                    </ul>
                </div>
            </footer>
        </div>
        <div id="mobile-menu">
                        <ul>
                            <li>
                                <div class="home">
                                    <a style="color: white" href="main-page.php"><i class="icon-home"></i>Log Out</a>
                                </div>                    
                            </li>                
                            <li><a href="comp-list-app.php">Batch and Payout Updates</a> 
                            </li>
                            <li><a style="color: black" href="https://www.google.com/maps/place/San+Pedro,+Pampanga/data=!4m2!3m1!1s0x3396f795a30d1207:0x19d88598da0068ee?sa=X&ved=1t:242&ictx=111" target="_blank">Location</a>
                            </li>
                            <li><a style="color: black" href="https://web.facebook.com/profile.php?id=61553531775372" target="_blank">Facebook</a>
                            </li>
                            <li><a style="color: black" href="https://mail.google.com/mail/u/0/#inbox?compose=DmwnWrRlQhfNVXGwDKmmfhWjqcCrHkSwZrlzvmpnxCPFhQbfVhghKVKNhzZpXqlXZfdwBGTgMzZg" target="_blank">Contact Us</a>
                            </li>
                        </ul>
                </div> <!-- /#rmm   -->
        <!-- PAGE FOR CREATE USER -->
            <div id="completeApplicationForm" data-role="page">
                <div data-role="header" data-position="fixed">
                    <center><h4>Complete Application</h4></center>
                </div>
                    <div data-role="content">     
                    <form action="#" method="post" id="frmCompleteApp" name="frmCompleteApp">
                        <div class="ui-field-contain">
                            <label for="Stud_ID_Create">Student ID:</label>
                            <input type="text" name="Stud_ID_Create" id="Stud_ID_Create" placeholder="Enter Student ID" value="" required>
                        </div>

                        <div class="ui-field-contain">
                            <label for="Applicant_Name_Create">Full Name:</label>
                            <input type="text" name="Applicant_Name_Create" id="Applicant_Name_Create" placeholder="Enter Name" value="" required>
                        </div>

                        <div class="ui-field-contain">
                            <label for="Date_of_Birth_Create">Date of Birth:</label>
                            <input type="text" name="Date_of_Birth_Create" id="Date_of_Birth_Create" placeholder="YYYY-MM-DD" value="" required>
                        </div>

                        <div class="ui-field-contain">
                            <label for="Educ_level_Create">Select Educational Level:</label>
                            <select name="Educ_level_Create" id="Educ_level_Create">
                                <option value="Senior High School">Senior High School</option>  
                                <option value="College">College</option>                    
                            </select>
                        </div>

                        <div class="ui-field-contain">
                            <label for="Year_level_Create">Select Year Level:</label>
                            <select name="Year_level_Create" id="Year_level_Create">
                                <option value="Grade 11">Grade 11</option>
                                <option value="Grade 12">Grade 12</option>  
                                <option value="1st Year College">1st Year College</option>
                                <option value="2nd Year College">2nd Year College</option>
                                <option value="3rd Year College">3rd Year College</option>
                                <option value="4th Year College">4th Year College</option>
                            </select>
                        </div>

                        <div class="ui-field-contain">
                            <label for="School_Create">School:</label>
                            <input type="text" name="School_Create" id="School_Create" placeholder="Enter School" value="" required>
                        </div>
                
                        <div class="ui-field-contain">
                            <label for="School_Address_Create">School Address:</label>
                            <textarea name="School_Address_Create" id="School_Address_Create" placeholder="Enter School Address" required></textarea>
                        </div>

                        <div class="ui-field-contain">
                            <label for="Course_or_Strand_Create">Course or Strand:</label>
                            <input type="text" name="Course_or_Strand_Create" id="Course_or_Strand_Create" placeholder="Enter Strand/Course" value="" required>
                        </div>
                    
                    </div>

                    <footer id="Ftr" data-role="footer" data-position="fixed">
                    <div data-role="navbar">                 
                        <ul>                   
                            <li><a type="button" href="#announcementPage" reloadPage="true" id="btnBackAnnounce" data-icon="back">Back To List</a></li>
                            <li><button type="submit" href="#" id="btnUpdateRecord" data-icon="action">Update Record</button></li>
                        </ul>

                    </div>
                </footer>
                </form>
            </div>
            
            <!-- Add JavaScript References -->
 <script src="../assets/js/user.js"></script>

  <!-- Include the  JavaScript References For the Sliding Menu -->
  <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/jquery.mobile-menu.min.js"></script>    
        <script>
            jQuery(document).ready(function($){		
                $("#mobile-menu").mobileMenu({
                    MenuWidth: 250,
                    SlideSpeed : 300,
                    WindowsMaxWidth : 767,
                    PagePush : true,
                    FromLeft : true,
                    Overlay : true,
                    CollapseMenu : true,
                    ClassName : "mobile-menu"
                });
            });        
        </script>  
    </body>
</html>
