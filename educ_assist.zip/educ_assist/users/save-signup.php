<?php
    // CALL DATABASE CONNECTION SCRIPT
    include("../config/database.php");

    // GET DATA FROM POST REQUEST
    $strUname = $_POST['Username_Create'];
    $strPass = $_POST['Password_Create'];
    $strEmail = $_POST['Email_Address_Create'];
    $strFname = $_POST['First_Name_Create'];
    $strMname = $_POST['Middle_Name_Create'];
    $strLname = $_POST['Last_Name_Create'];
    
    // ADDITIONAL DATA FOR tbl_applicant_info
    $strStudID = $_POST['Stud_ID_Create'];
    $strApplicantName = $strFname . ' ' . $strMname . ' ' . $strLname; 
    $strDOB = $_POST['Date_of_Birth_Create'];
    $strEducLevel = $_POST['Educ_level_Create'];
    $strYearLevel = $_POST['Year_Level_Create']; 
    $strSchool = $_POST['School_Create'];
    $strSchoolAddress = $_POST['School_Address_Create']; 
    $strCourseOrStrand = $_POST['Course_or_Strand_Create']; 
    $strBatchID = $_POST['Batch_ID_Create']; 

    // CREATE QUERY TO INSERT RECORDS INTO tbl_applicant
    $query = "INSERT INTO tbl_applicant (
        Applicant_username, 
        Applicant_password, 
        Applicant_email, 
        Applicant_FName, 
        Applicant_MName, 
        Applicant_LName
    ) VALUES (
        :uname, 
        :pass, 
        :email, 
        :fname, 
        :mname, 
        :lname
    )";

    // PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
    $stmt = $pdo->prepare($query);

    // BIND PARAMETER VALUES
    $stmt->bindParam(":uname", $strUname);
    $stmt->bindParam(":pass", $strPass); 
    $stmt->bindParam(":email", $strEmail);
    $stmt->bindParam(":fname", $strFname);
    $stmt->bindParam(":mname", $strMname);
    $stmt->bindParam(":lname", $strLname);

    // EXECUTE STATEMENT
    $stmt->execute();

    $applicantId = $pdo->lastInsertId(); 

    // CREATE QUERY TO INSERT RECORDS INTO tbl_applicant_info
    $infoQuery = "INSERT INTO tbl_applicant_info (
        Applicant_ID, 
        Stud_ID, 
        Applicant_Name, 
        Date_of_Birth, 
        Educ_level, 
        Year_level, 
        School, 
        School_address, 
        Course_or_Strand, 
        Batch_ID
    ) VALUES (
        :applicantId, 
        :studID, 
        :applicantName, 
        :dob, 
        :educLevel, 
        :yearLevel, 
        :school, 
        :schoolAddress, 
        :courseOrStrand, 
        :batchID
    )";

    // Prepare statement for tbl_applicant_info
    $infoStmt = $pdo->prepare($infoQuery);

    // Bind parameters for tbl_applicant_info
    $infoStmt->bindParam(":applicantId", $applicantId);
    $infoStmt->bindParam(":studID", $strStudID);
    $infoStmt->bindParam(":applicantName", $strApplicantName);
    $infoStmt->bindParam(":dob", $strDOB);
    $infoStmt->bindParam(":educLevel", $strEducLevel);
    $infoStmt->bindParam(":yearLevel", $strYearLevel);
    $infoStmt->bindParam(":school", $strSchool);
    $infoStmt->bindParam(":schoolAddress", $strSchoolAddress);
    $infoStmt->bindParam(":courseOrStrand", $strCourseOrStrand);
    $infoStmt->bindParam(":batchID", $strBatchID);

    // EXECUTE THE SECOND QUERY
    $infoStmt->execute();

    header("Location: loginapp-page.php"); 
    exit();
?>
