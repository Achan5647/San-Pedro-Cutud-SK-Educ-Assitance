<?php
error_reporting(0);
//CALL DATABASE CONNECTION SCRIPT
include("../config/database.php");

//CREATE THE QUERY TO SELECT ALL RECORDS FROM THE TABLE
$query="SELECT COUNT(*) as totCount FROM tbl_admin WHERE Admin_username=? AND Admin_password=?";

//PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
$stmt = $pdo->prepare($query);

$uname = isset($_GET['uname']) ? $_GET['uname'] : die();
$pass = isset($_GET['pass']) ? $_GET['pass'] : die();
//BIND VALUE TO DATABASE PARAMETER
$stmt->bindValue(1, $uname);
$stmt->bindValue(2, $pass);

//EXECUTE STATEMENT
$stmt->execute();

$user_arr=array();
$user_arr["records"]=array();

//GET RECORDS PER ROW
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    // extract row
    // this will make $row['name'] to
    // just $name only
    extract($row);

    $user_arr = array(
        "totCount" =>  $totCount
    );
    }
    echo json_encode($user_arr);
?>