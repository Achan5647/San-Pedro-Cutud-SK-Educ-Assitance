<?php
    //CALL DATABASE CONNECTION SCRIPT
    include("../config/database.php");
  
    //GET USER INPUT FROM WEB FORM
    $strUname = $_POST['Username_Create'];
    $strPass = $_POST['Password_Create'];
    $strEmail = $_POST['Email_Address_Create'];
    $strFname = $_POST['First_Name_Create'];
    $strMname = $_POST['Middle_Name_Create'];
    $strLname = $_POST['Last_Name_Create'];
    $strPicPath = "profPhoto.jpg";
    
    //CREATE QUERY TO INSERT RECORDS
    $query = "INSERT INTO tbl_applicant SET
    Applicant_username=:uname, 
    Applicant_password=:pass,  
    Applicant_email=:email, 
    Applicant_FName=:fname,
    Applicant_MName=:mname,
    Applicant_LName=:lname,
    PicPath=:path";

    //PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
    $stmt = $pdo->prepare($query);

    //BIND PARAMETER VALUES
    $stmt->bindParam(":uname", $strUname);
    $stmt->bindParam(":pass", $strPass);
    $stmt->bindParam(":email", $strEmail);
    $stmt->bindParam(":fname", $strFname);
    $stmt->bindParam(":mname", $strMname);
    $stmt->bindParam(":lname", $strLname);
    $stmt->bindParam(":path", $strPicPath);

    //EXECUTE STATEMENT
    $stmt->execute();  
?>
