<!DOCTYPE html>
<html>
    <head>
        <title>ADMIN HOMEPAGE</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Include jQuery Mobile stylesheets -->
        <link rel="stylesheet" href="../../jquery/jquery.mobile-1.4.5.min.css">

        <!-- Include the jQuery library -->
        <script src="../../jquery/jquery-1.11.3.js"></script>

        <!-- Include the jQuery Mobile library -->
        <script src="../../jquery/jquery.mobile-1.4.5.min.js"></script>

        <link rel="stylesheet" href="../assets/css/custom.css">
        
        <div id="AdminList" data-role="page">
            <div data-role="header" data-position="fixed">
                <center><h4>ADMIN LIST</h4></center>
                <div class="mm-toggle-wrap">
                    <div class="mm-toggle">
                        <i class="icon-menu"></i><span class="mm-label">ADMIN LIST</span>
                    </div>            
                </div>
            </div>
            
            <div data-role="content">          
                <ul data-role="listview" style="white-space:normal">  
                    <?php
                        error_reporting(0);
                        //CALL DATABASE CONNECTION SCRIPT
                        include("../config/database.php");

                        //CREATE THE QUERY TO SELECT ALL RECORDS FROM THE TABLE
                        $query="SELECT * FROM tbl_admin";
                    
                        //PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
                        $stmt = $pdo->prepare($query);
                        
                        //EXECUTE STATEMENT
                        $stmt->execute();

                        //GET RECORDS PER ROW
                        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        //LOOP AND STORE DATA RECORDS TO VARIABLES
                        foreach($rows as $row){      
                                $uid = $row["Admin_ID"];
                                $uname = $row["Admin_username"];
                                $pass = $row["Admin_password"];
                                $email = $row["Admin_email"];
                                $pos = $row["Admin_Position"];
                                $picpath = $row["PicPath"];

                            //DISPLAY RECORDS AS LIST
                            echo'    
                            <li>
                                <a href="#viewRecord?id='.$uid.'" rel="external" data-transition="slide" id="userLink">
                                <img class="imgUserIcon" alt="sample" src="../assets/images/'.$picpath.'" align="left"/>
                                '.$uid.'

                                <br>
                                <font style="font-size: small">
                                '.$uname.', '.$email.'

                                <br>
                                '.$pos.'
                                </font>
                                </a>
                            </li>
                            ';              
                            }
                        ?>
                    </ul>
                    <footer id="Ftr" data-role="footer" data-position="fixed">
                        <div data-role="navbar">
                            <ul>                   
                                <li><a type="button" onclick="window.location.href='#createAdminForm'" id="btnCreate" reload="true" data-icon="plus" data-transition="slide">Add New Admin</a></li>
                            </ul>
                        </div>
                    </footer>
                </div>
            </div>
            <!-- PAGE FOR CREATE USER -->
     <div id="createAdminForm" data-role="page">
        <div data-role="header" data-position="fixed">
            <center><h4>CREATE NEW ADMINISTRATOR</h4></center>
        </div>
            <div data-role="content">     
            <form action="#" method="post" id="frmCreateAdmin" name="frmCreateAdmin">
                <!-- TEXT INPUT ELEMENTS -->

                <div class="ui-field-contain">
                    <label for="Admin_Username_Create">Username:</label>
                    <input type="text" name="Admin_Username_Create" id="Admin_Username_Create" placeholder="Enter Username" value="" required>
                </div>

                  <div class="ui-field-contain">
                    <label for="Admin_Password_Create">Password:</label>
                    <input type="text" name="Admin_Password_Create" id="Admin_Password_Create" placeholder="Enter Password" value="" required>
                </div>

                  <div class="ui-field-contain">
                    <label for="Admin_Email_Create">Email:</label>
                    <input type="email" name="Admin_Email_Create" id="Admin_Email_Create" placeholder="Enter Email" value="" required>
                </div>

                <div class="ui-field-contain">
                    <label for="Admin_Position_Create">Position:</label>
                    <input type="text" name="Admin_Position_Create" id="Admin_Position_Create" placeholder="Enter Position" value="" required>
                </div>
               
            </div>

             <footer id="Ftr" data-role="footer" data-position="fixed">
             <div data-role="navbar">                 
                <ul>                   
                    <li><a type="button" onclick="window.location.href='admin-home.php'" reloadPage="true" id="btnBack" data-icon="back">Back To List</a></li>
                    <li><button type="submit" href="#" id="btnCreate" data-icon="action">Save Record</button></li>
                </ul>

            </div>
        </footer>
        </form>
    </div>

            <!-- PAGE FOR VIEW RECORD -->
            <div id="viewRecord" data-role="page">
                <div data-role="header" data-position="fixed">
                <center><h4>VIEW ADMIN INFO</h4></center>
                </div>
                    <div data-role="content">              
                        <img class="imgUser" id="imgUser">
                        <table data-role="table" id="movie-table" data-mode="reflow" class="ui-responsive">
                        <thead>
                            <th data-priority="1">Admin ID</th>
                            <th data-priority="2">Admin Username</th>
                            <th data-priority="3">Admin Password</th>
                            <th data-priority="4">Admin Email</th>
                            <th data-priority="5">Admin Position</th>
                            </tr>
                        </thead>
                        <tbody>                 
                            <tr>
                            <td><em id="uid"></td>
                            <td><em id="uname"></td>
                            <td><em id="pass"></td>
                            <td><em id="email"></td>
                            <td><em id="pos">></td>                
                            </tr>                 
                        </tbody>
                        </table>              
                    </div>
                    <footer id="Ftr" data-role="footer" data-position="fixed">
                    <div data-role="navbar">                 
                        <ul>                   
                            <li><a type="button" onclick="window.location.href='admin-home.php'" id="btnList" data-icon="arrow-l" reloadPage="true" data-transition="slide">Back</a></li>
                            <li><a type="button" href="#editAdminForm" id="btnEdit" data-icon="edit" reloadPage="true" data-transition="slide">Edit Record</a></li>
                            <li><a type="button" href="#" id="btnDelete" data-icon="delete">Delete Record</a></li>
                        </ul>
                    </div>
            </div>
        
        <!-- PAGE FOR EDIT USER -->
 <div id="editAdminForm" data-role="page">
        <div data-role="header" data-position="fixed">
            <center><h4>EDIT ADMIN RECORD</h4></center>
        </div>
            <div data-role="content">     
            <form action="#" method="post" id="frmEditAdmin" name="frmEditAdmin">
                <!-- TEXT INPUT ELEMENTS -->
                <div class="ui-field-contain">
                    <label for="Admin_Username_Edit">Username:</label>
                    <input type="text" name="Admin_Username_Edit" id="Admin_Username_Edit" placeholder="Enter Username" value="" required>
                </div>

                  <div class="ui-field-contain">
                    <label for="Admin_Password_Edit">Password:</label>
                    <input type="text" name="Admin_Password_Edit" id="Admin_Password_Edit" placeholder="Enter Password" value="" required>
                </div>

                  <div class="ui-field-contain">
                    <label for="Admin_Email_Edit">Email:</label>
                    <input type="email" name="Admin_Email_Edit" id="Admin_Email_Edit" placeholder="Enter Email" value="" required>
                </div>

                <div class="ui-field-contain">
                    <label for="Admin_Position_Edit">Position:</label>
                    <input type="text" name="Admin_Position_Edit" id="Admin_Position_Edit" placeholder="Enter Position" value="" required>
                </div>

             <footer id="Ftr" data-role="footer" data-position="fixed">
             <div data-role="navbar">                 
                <ul>                   
                    <li><a type="button" onclick="window.location.href='admin-home.php'" reloadPage="true" id="btnBack1" data-icon="back">Back</a></li>
                    <li><button type="submit" href="#" id="btnEdit" data-icon="action">Edit Record</button></li>
                </ul>

             </div>
        </footer>
        </form>
    </div>	
    </head>

    <body>
        <!-- JavaScript -->
        <script src="../assets/js/user.js"></script>
    </body>
</html>
