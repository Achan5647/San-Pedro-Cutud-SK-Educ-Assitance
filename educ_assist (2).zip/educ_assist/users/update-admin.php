<?php
    //CALL DATABASE CONNECTION SCRIPT
    include("../config/database.php");
  
    //GET USER INPUT FROM WEB FORM
    $strUname = $_POST['Admin_Username_Edit'];
    $strPass = $_POST['Admin_Password_Edit'];
    $strEmail = $_POST['Admin_Email_Edit'];
    $strPos = $_POST['Admin_Position_Edit'];
  

    //CREATE QUERY TO INSERT RECORDS
    $query = "UPDATE tbl_admin SET 
    Admin_username=:uname, 
    Admin_password=:pass, 
    Admin_email=:email, 
    Admin_Position=:pos
    WHERE Admin_ID=:uid";

    //PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
    $stmt = $pdo->prepare($query);

    //BIND PARAMETER VALUES
    $stmt->bindParam(":uid", $uid);
    $stmt->bindParam(":uname", $strUname);
    $stmt->bindParam(":pass", $strPass);
    $stmt->bindParam(":email", $strEmail);
    $stmt->bindParam(":pos", $strPos);
    
    //EXECUTE STATEMENT
    $stmt->execute();  
?>