<?php
error_reporting(0);
//CALL DATABASE CONNECTION SCRIPT
include("../config/database.php");

//CREATE THE QUERY TO SELECT ALL RECORDS FROM THE TABLE
$query="SELECT * FROM tbl_admin WHERE Admin_ID=?";

//PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
$stmt = $pdo->prepare($query);

$id = isset($_GET['id']) ? $_GET['id'] : die();
//BIND VALUE TO DATABASE PARAMETER
$stmt->bindValue(1, $id);

//EXECUTE STATEMENT
$stmt->execute();

$user_arr=array();
$user_arr["records"]=array();

//GET RECORDS PER ROW
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    // extract row
    // this will make $row['name'] to
    // just $name only
    extract($row);

    $user_arr = array(
        "Admin_ID" =>  $Admin_ID,
        "Admin_username" => $Admin_username,
        "Admin_password" => $Admin_password,
        "Admin_email" => $Admin_email,
        "Admin_Position" => $Admin_Position,
        "PicPath" => $PicPath   
    );
    }
    echo json_encode($user_arr);
?>
