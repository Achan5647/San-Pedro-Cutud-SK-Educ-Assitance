<?php
error_reporting(0);
//CALL DATABASE CONNECTION SCRIPT
include("../config/database.php");

//CREATE THE QUERY TO SELECT ALL RECORDS FROM THE TABLE
$query="DELETE  FROM tbl_admin WHERE Admin_ID=?";

//PREPARE QUERY AND STORE TO A STATEMENT VARIABLE
$stmt = $pdo->prepare($query);

$id = isset($_GET['id']) ? $_GET['id'] : die();
//BIND VALUE TO DATABASE PARAMETER
$stmt->bindValue(1, $id);

//EXECUTE STATEMENT
$stmt->execute();

echo json_encode(array("message" => "Record  was deleted."));
?>