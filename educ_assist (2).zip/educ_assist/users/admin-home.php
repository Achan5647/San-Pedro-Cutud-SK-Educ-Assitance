<!DOCTYPE html>
<html>
    <head>
        <title>ADMIN HOMEPAGE</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Include jQuery Mobile stylesheets -->
        <link rel="stylesheet" href="../../jquery/jquery.mobile-1.4.5.min.css">

        <!-- Include the jQuery library -->
        <script src="../../jquery/jquery-1.11.3.js"></script>

        <!-- Include the jQuery Mobile library -->
        <script src="../../jquery/jquery.mobile-1.4.5.min.js"></script>

        <!-- Include the CSS For the Sliding Menu -->
        <link href="../assets/css/normalize.css" rel="stylesheet">
        <link href="../assets/css/site-icons.css" rel="stylesheet">
        <link href="../assets/css/style.css" rel="stylesheet">
        <link href="../assets/css/jquery.mobile-menu.css" rel="stylesheet">
    
        
    </head>

    <body>
    <div id="overlay"></div>
        <div id="AdminHome" data-role="page">
        <div data-role="header" data-position="fixed">
            <center><h4>ADMIN HOME</h4></center>
            <div class="mm-toggle-wrap">
                <div class="mm-toggle">
                    <i class="icon-menu"></i><span class="mm-label">ADMIN</span>
                </div>            
            </div>
        </div>
        </div>
            
            <div id="mobile-menu">
                        <ul>
                            <li>
                                <div class="home">
                                    <a href="main-page.php"><i class="icon-home"></i>Log Out</a>
                                </div>                    
                            </li>                
                            <li><a href="admin-list.php">Admin List</a> 
                            </li>
                            <li><a href="app-list.php">Applicants</a>
                            </li>
                            <li><a href="#">Batches</a>
                            </li>
                            <li><a href="#">Payout</a>
                            </li>
                            <li><a href="#">Locations</a>
                                <ul>
                                    <li><a href="#">West Coast</a>
                                        <ul>
                                            <li><a href="#">West Coast 1</a></li>
                                            <li><a href="#">West Coast 2</a></li>
                                            <li><a href="#">West Coast 3</a></li>
                                            <li><a href="#">West Coast 4</a></li>
                                            <li><a href="#">West Coast 5</a></li>
                                            <li><a href="#">West Coast 6</a></li>
                                            <li><a href="#">West Coast 7</a></li>
                                            <li><a href="#">West Coast 8</a></li>
                                            <li><a href="#">West Coast 9</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Central</a>
                                        <ul>
                                            <li><a href="#">Central 1</a></li>
                                            <li><a href="#">Central 2</a></li>
                                            <li><a href="#">Central 3</a></li>
                                            <li><a href="#">Central 4</a></li>
                                            <li><a href="#">Central 5</a></li>
                                            <li><a href="#">Central 6</a></li>
                                            <li><a href="#">Central 7</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">East Coast</a>
                                        <ul>
                                            <li><a href="#">East Coast 1</a></li>
                                            <li><a href="#">East Coast 2</a></li>
                                            <li><a href="#">East Coast 3</a></li>
                                            <li><a href="#">East Coast 4</a></li>
                                            <li><a href="#">East Coast 5</a></li>
                                            <li><a href="#">East Coast 6</a></li>
                                            <li><a href="#">East Coast 7</a></li>
                                            <li><a href="#">East Coast 8</a></li>
                                            <li><a href="#">East Coast 9</a></li>
                                            <li><a href="#">East Coast 10</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="#">Careers</a>
                                <ul>
                                    <li><a href="#">Professionals</a>
                                        <ul>
                                            <li><a href="#">Professionals</a></li>
                                            <li><a href="#">Professionals</a></li>
                                            <li><a href="#">Professionals</a></li>
                                            <li><a href="#">Professionals</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Students</a>
                                        <ul>
                                            <li><a href="#">Students</a></li>
                                            <li><a href="#">Students</a></li>
                                            <li><a href="#">Students</a></li>
                                            <li><a href="#">Students</a></li>
                                            <li><a href="#">Students</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="#">Contact Us</a>
                                <ul>
                                    <li><a href="#">Contact Us 2</a>
                                    </li>
                                    <li><a href="#">Contact Us 2</a>
                                    </li>
                                    <li><a href="#">Store Locator</a>
                                    </li>
                                    <li><a href="#">Global Networks</a>
                                    </li>
                                    <li><a href="#">Social Media</a>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="#">Blog</a></li> 
                            <li>
                                <div class="social">
                                    <a href="#" title="Follow Us on LinkedIn"><i class="icon-linkedin-squared"></i></a>
                                    <a href="#" title="Follow Us on Facebook"><i class="icon-facebook-squared"></i></a>
                                    <a href="#" title="Follow Us on Twitter"><i class="icon-twitter-squared"></i></a>
                                    <a href="#" title="Follow Us on Google+"><i class="icon-gplus-squared"></i></a>
                                    <a href="#" title="Follow Us on Youtube"><i class="icon-youtube-play"></i></a>
                                </div>
                            </li>
                        </ul>
                </div> <!-- /#rmm   -->
        <!-- JavaScript -->
        <script src="../assets/js/user.js"></script>

    <!-- Include the  JavaScript References For the Sliding Menu -->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/jquery.mobile-menu.min.js"></script>    
        <script>
            jQuery(document).ready(function($){		
                $("#mobile-menu").mobileMenu({
                    MenuWidth: 250,
                    SlideSpeed : 300,
                    WindowsMaxWidth : 767,
                    PagePush : true,
                    FromLeft : true,
                    Overlay : true,
                    CollapseMenu : true,
                    ClassName : "mobile-menu"
                });
            });        
        </script>  

    </body>
</html>



