$(document).ready(function () {

    $("#mobile-menu").mobileMenu({
        MenuWidth: 250,
        SlideSpeed : 300,
        WindowsMaxWidth : 767,
        PagePush : true,
        FromLeft : true,
        Overlay : true,
        CollapseMenu : true,
        ClassName : "mobile-menu"
    });

    $('#btnSignUp').click(function () {
        console.log("Navigating to #userSignUp"); // Debug log

        // Navigate to internal page
        $.mobile.changePage('#userSignUp', {
            transition: 'slide', // Add slide transition
        });
    });

    // Handle Sign-Up Form Submission
    
});

//WHEN CREATE BUTTON WAS CLICKED
$(document).on('submit', '#frmCreateAdmin', function(){  
    //GET USER INPUTS FROM HTML FORMS
    var values = $(this).serialize();
  
    //CREATE AJAX TO CALL SAVE-USER PHP SCRIPT
    $.ajax({
           url: "save-admin.php",
           type: "POST",
           data: values ,
           success: function (response) {
              //CLEAR USER INPUTS
              $('#frmCreateAdmin')[0].reset();  
           },
           error: function(jqXHR, textStatus, errorThrown) {
              console.log(textStatus, errorThrown);
           }
       });
     
   });

$(document).on('submit', '#frmUserSignUp', function (e) {
        e.preventDefault(); // Prevent form submission

        // Serialize form data
        var values = $(this).serialize();
        console.log("Sign-Up Form Data:", values); // Debug log

        // Perform AJAX request
        $.ajax({
            url: 'save-signup.php',
            type: 'POST',
            data: values,
            success: function (response) {
                console.log("Sign-Up Success:", response); // Debug log
                alert('User registered successfully!');
                $('#frmUserSignUp')[0].reset(); // Reset form
                $.mobile.changePage('admin-home.php', {
                    transition: 'slide', 
                    reloadPage: true 
                });
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.error('Sign-Up Error:', textStatus, errorThrown); // Debug log
            }
        });


    });

$('#viewRecord').bind('pageshow', onReadOne);
    function onReadOne(e,data)
   {
       adminid = getUrlVars()["id"];
       $.ajax({
       url: "read-one-admin.php?id=" + adminid,
       type : "POST",
       dataType : 'json',
       success : function(result) {   
           document.getElementById("uid").innerHTML = result.Admin_ID; 
           document.getElementById("uname").innerHTML = result.Admin_username; 
           document.getElementById("pass").innerHTML = result.Admin_password; 
           document.getElementById("email").innerHTML = result.Admin_email; 
           document.getElementById("pos").innerHTML = result.Admin_Position; 
           document.getElementById("imgUser").src = "../assets/images/profPhoto.jpg";           
       },
       error: function(xhr, resp, text) {
       console.log(xhr, resp, text);
       }
   }); 
   }	    

$(document).on('submit', '#frmAdminLogIn', function(){     
    //GET USER INPUTS FROM HTML FORMS
    aduname =  document.getElementById("Admin_Username_Log").value;
    adpass =  document.getElementById("Admin_Pass_Log").value;
    
    //CREATE AJAX TO CALL UPDATE-USER PHP SCRIPT
    $.ajax({
        url: "loginad.php?uname=" + aduname + "&pass=" + adpass,
        type : "POST",
        dataType : 'json',
        success : function(result) {
           intCount = result.totCount; 
           if(intCount==1){
                $.mobile.changePage("admin-home.php", { transition: "slide", reloadPage:true })   
           }                
        },
        error: function(xhr, resp, text) {
        console.log(xhr, resp, text);
        }
       });
   });
   $('#editUserForm').bind('pageshow', onEditForm);
   function onEditForm(e,data)
   {
      adminid = document.getElementById("uid").innerHTML;
      $.ajax({
      url: "read-one-admin.php?id=" + adminid,
      type : "POST",
      dataType : 'json',
      success : function(result) {
          document.getElementById("Admin_Username_Edit").value = result.Admin_username; 
          document.getElementById("Admin_Password_Edit").value = result.Admin_password; 
          document.getElementById("Admin_Email_Edit").value = result.Admin_email; 
          document.getElementById("Admin_Position_Edit").value = result.Admin_Position;          
      },
      error: function(xhr, resp, text) {
      console.log(xhr, resp, text);
      }
   }); 
   }
     
   //WHEN EDIT BUTTON WAS CLICKED
   $(document).on('submit', '#frmEditAdmin', function(){  
       //GET USER INPUTS FROM HTML FORMS
       var values = $(this).serialize();
     
       //CREATE AJAX TO CALL UPDATE-USER PHP SCRIPT
       $.ajax({
              url: "update-admin.php",
              type: "POST",
              data: values ,
              success: function (response) {
                 $('#frmEditAdmin')[0].reset();
                 $.mobile.changePage('admin-home.php', {
                    transition: 'slide', 
                    reloadPage: true 
                }); 
              },
              error: function(jqXHR, textStatus, errorThrown) {
                 console.log(textStatus, errorThrown);
              }
          });
        
      });
    $(document).on('click', '#btnDelete', function(){  
        userid = getUrlVars()["id"];
        $.ajax({
        url: "delete-admin.php?id=" + userid,
        type : "POST",
        dataType : 'json',
        success : function(result) {   
            $.mobile.changePage( "admin-home.php", { transition: "slide", reloadPage:true })     
        },
        error: function(xhr, resp, text) {
        console.log(xhr, resp, text);
        }
        }); 
    });
   function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        vars[key] = value;
    });
    return vars;
    }
